﻿// Copyright 2020 Mickael Daniel. All Rights Reserved.


#include "GASCompanionTestsNativeTags.h"

FGASCompanionTestsNativeTags FGASCompanionTestsNativeTags::NativeTags;
