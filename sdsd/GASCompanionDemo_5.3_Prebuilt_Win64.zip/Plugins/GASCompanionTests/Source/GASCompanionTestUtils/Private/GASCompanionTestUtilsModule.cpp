﻿// Copyright 2021-2022 Mickael Daniel. All Rights Reserved.

#include "GASCompanionTestUtilsModule.h"

#define LOCTEXT_NAMESPACE "FGASCompanionTestUtilsModule"

void FGASCompanionTestUtilsModule::StartupModule()
{
}

void FGASCompanionTestUtilsModule::ShutdownModule()
{
    
}

#undef LOCTEXT_NAMESPACE
    
IMPLEMENT_MODULE(FGASCompanionTestUtilsModule, GASCompanionTestUtils)